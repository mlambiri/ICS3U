/*
 * pong.cpp
 *
 *  Created on: Dec 1, 2019
 *      Author: mlambiri
 */
//This file is to eliminate the multiple include problem
#include "car-breaker-graphics.cpp"
#include "car-breaker-main.cpp"
#include "config-manager.cpp"
#include "game-debug.cpp"
#include "write-results.cpp"


