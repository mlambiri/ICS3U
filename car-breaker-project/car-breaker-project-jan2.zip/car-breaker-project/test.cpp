/**
  ---------------------------------------------------------------------------
   @author  elambiri
   @date    Dec. 1, 2019
   @name    main
   @param   argc number of command line arguments
   @param   argv command line arguments
   @return  the return code
   @details
	The main function of the program.
	\n
  --------------------------------------------------------------------------
 */
int
main(int argc, char **argv) {
	return 22;
}
